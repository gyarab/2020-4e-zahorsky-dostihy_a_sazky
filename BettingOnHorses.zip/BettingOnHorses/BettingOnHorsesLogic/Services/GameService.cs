﻿using BettingOnHorsesLogic.Contracts;
using BettingOnHorsesModel.Contracts;
using BettingOnHorsesModel.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Media;

namespace BettingOnHorsesLogic.Services
{
    /// <summary>
    /// Třída představující připravení hry a následné operace, které se ve hře dějí.
    /// </summary>
    public class GameService
    {
        /// <summary>
        /// Metoda pro připravení hry, pro počet hráčů, který dostane v parametru. 
        /// Nastaví hráčům a kartám hodnoty, zavolá funkci GetLocation, která jim přidělí pozici na hrací ploše. 
        /// Připraví stáje a přiřadí je kartám koní.
        /// Vrací instanci game.
        /// </summary>
        public Game CreateGame(int numberOfPlayers)
        {
            var game = new Game()
            {
                Board = new Board(),
                Players = new List<Player>(),
                Status = BettingOnHorsesModel.Enums.GameStatus.active
            };

            //Připraví barvy hráčů
            var playerColors = new List<string>();
            playerColors.Add("Blue");
            playerColors.Add("DarkOrange");
            playerColors.Add("Green");
            playerColors.Add("Red");

            //Připraví hráče
            for (int i = 0; i < numberOfPlayers; i++)
            {
                game.Players.Add(new Player() { Name = "P" + (i + 1), Cash = 30000, BoardIndex = 0, BoardLocation = Board.GetLocation(0), Color = playerColors[i], GameIndex = i, IsActive = true, DiceRolled = false });
            }

            //Určí prvního hráče na tahu
            game.PlayerOnTurn = game.Players.Where(x => x.GameIndex == 0).FirstOrDefault();

            //Připraví kartu start
            var start = new StartCard() { Game = game, BoardIndex = 0, Title = "START", Price = 0, BoardLocation = Board.GetLocation(0)};
            game.Board.Add(start);

            //Připraví stáje
            var orangeStable = new Stable() { StableColor = "Coral" };
            var darkRedStable = new Stable() { StableColor = "IndianRed" };
            var blueStable = new Stable() { StableColor = "PowderBlue" };
            var greenStable = new Stable() { StableColor = "MediumAquamarine" };
            var redStable = new Stable() { StableColor = "LightCoral" };
            var yellowStable = new Stable() { StableColor = "Gold" };
            var darkGreenStable = new Stable() { StableColor = "Olive" };
            var purpleStable = new Stable() { StableColor = "Thistle" };

            //Připraví karty koní a trenérů
            var fantome = new HorseCard() { Game = game, BoardIndex = 1, Title = "Fantome", Price = 1200, BoardLocation = Board.GetLocation(1), Stable = orangeStable, InspectionPrice = 40, BetCost = 1000, BetPrice = new List<int> { 200, 600, 1800, 3200, 5000} };
            game.Board.Add(fantome); 
            var gavora = new HorseCard() { Game = game, BoardIndex = 2, Title = "Gavora", Price = 1200, BoardLocation = Board.GetLocation(2), Stable = orangeStable, InspectionPrice = 40, BetCost = 1000, BetPrice = new List<int> { 200, 600, 1800, 3200, 5000 } };
            game.Board.Add(gavora);

            var trainer1 = new TrainerCard() { Game = game, Title = "Trenér 1",BoardIndex = 3, BoardLocation = Board.GetLocation(3), InspectionPrice = 1000 };
            game.Board.Add(trainer1);

            var ladyAnne = new HorseCard() { Game = game, BoardIndex = 4, Title = "Lady Anne", Price = 2000, BoardLocation = Board.GetLocation(4), Stable = darkRedStable, InspectionPrice = 120, BetCost = 1000, BetPrice = new List<int> { 600, 1800, 5400, 8000, 11000 } };
            game.Board.Add(ladyAnne);
            var pasek = new HorseCard() { Game = game, BoardIndex = 5, Title = "Pasek", Price = 2000, BoardLocation = Board.GetLocation(5), Stable = darkRedStable, InspectionPrice = 120, BetCost = 1000, BetPrice = new List<int> { 600, 1800, 5400, 8000, 11000 } };
            game.Board.Add(pasek);
            var koran = new HorseCard() { Game = game, BoardIndex = 6, Title = "Koran", Price = 2400, BoardLocation = Board.GetLocation(6), Stable = darkRedStable, InspectionPrice = 160, BetCost = 1000, BetPrice = new List<int> { 800, 2000, 6000, 9000, 12000 } };
            game.Board.Add(koran);

            var neklan = new HorseCard() { Game = game, BoardIndex = 7, Title = "Neklan", Price = 2800, BoardLocation = Board.GetLocation(7), Stable = blueStable, InspectionPrice = 200, BetCost = 2000, BetPrice = new List<int> { 1000, 3000, 9000, 12500, 15000 } };
            game.Board.Add(neklan);
            var portlancl = new HorseCard() { Game = game, BoardIndex = 8, Title = "Portlancl", Price = 2800, BoardLocation = Board.GetLocation(8), Stable = blueStable, InspectionPrice = 200, BetCost = 2000, BetPrice = new List<int> { 1000, 3000, 9000, 12500, 15000 } };
            game.Board.Add(portlancl);
            var japan = new HorseCard() { Game = game, BoardIndex = 9, Title = "Japan", Price = 2800, BoardLocation = Board.GetLocation(9), Stable = blueStable, InspectionPrice = 240, BetCost = 2000, BetPrice = new List<int> { 1200, 3600, 10000, 14000, 18000 } };
            game.Board.Add(japan);

            var trainer2 = new TrainerCard() { Game = game, Title = "Trenér 2", BoardIndex = 10, BoardLocation = Board.GetLocation(10), InspectionPrice = 1000 };
            game.Board.Add(trainer2);

            var kostrava = new HorseCard() { Game = game, BoardIndex = 11, Title = "Kostrava", Price = 3600, BoardLocation = Board.GetLocation(11), Stable = greenStable, InspectionPrice = 280, BetCost = 2000, BetPrice = new List<int> { 1400, 4000, 11000, 15000, 19000 } };
            game.Board.Add(kostrava);
            var lukava = new HorseCard() { Game = game, BoardIndex = 12, Title = "Lukava", Price = 3600, BoardLocation = Board.GetLocation(12), Stable = greenStable, InspectionPrice = 280, BetCost = 2000, BetPrice = new List<int> { 1400, 4000, 11000, 15000, 19000 } };
            game.Board.Add(lukava);
            var melak = new HorseCard() { Game = game, BoardIndex = 13, Title = "Melák", Price = 4000, BoardLocation = Board.GetLocation(13), Stable = greenStable, InspectionPrice = 320, BetCost = 2000, BetPrice = new List<int> { 1600, 4400, 12000, 16000, 20000 } };
            game.Board.Add(melak);

            //Připraví kartu parkoviště
            var parking = new ParkingCard() { Game = game, BoardIndex = 14, Title = "PARKOVIŠTĚ", Price = 0, BoardLocation = Board.GetLocation(14) };
            game.Board.Add(parking);

            var grifel = new HorseCard() { Game = game, BoardIndex = 15, Title = "Grifel", Price = 4400, BoardLocation = Board.GetLocation(15), Stable = redStable, InspectionPrice = 360, BetCost = 3000, BetPrice = new List<int> { 1800, 5000, 14000, 17000, 21000 } };
            game.Board.Add(grifel);
            var mohyla = new HorseCard() { Game = game, BoardIndex = 16, Title = "Mohyla", Price = 4400, BoardLocation = Board.GetLocation(16), Stable = redStable, InspectionPrice = 360, BetCost = 3000, BetPrice = new List<int> { 1800, 5000, 14000, 17000, 21000 } };
            game.Board.Add(mohyla);
            var metal = new HorseCard() { Game = game, BoardIndex = 17, Title = "Metál", Price = 4800, BoardLocation = Board.GetLocation(17), Stable = redStable, InspectionPrice = 400, BetCost = 3000, BetPrice = new List<int> { 2000, 6000, 15000, 18000, 22000 } };
            game.Board.Add(metal);

            var trainer3 = new TrainerCard() { Game = game, Title = "Trenér 3", BoardIndex = 18, BoardLocation = Board.GetLocation(18), InspectionPrice = 1000 };
            game.Board.Add(trainer3);

            var tara = new HorseCard() { Game = game, BoardIndex = 19, Title = "Tara", Price = 5200, BoardLocation = Board.GetLocation(19), Stable = yellowStable, InspectionPrice = 440, BetCost = 3000, BetPrice = new List<int> { 2200, 6600, 16000, 19500, 23000 } };
            game.Board.Add(tara);
            var furioso = new HorseCard() { Game = game, BoardIndex = 20, Title = "Furioso", Price = 5200, BoardLocation = Board.GetLocation(20), Stable = yellowStable, InspectionPrice = 440, BetCost = 3000, BetPrice = new List<int> { 2200, 6600, 16000, 19500, 23000 } };
            game.Board.Add(furioso);
            var genius = new HorseCard() { Game = game, BoardIndex = 21, Title = "Genius", Price = 5200, BoardLocation = Board.GetLocation(21), Stable = yellowStable, InspectionPrice = 580, BetCost = 3000, BetPrice = new List<int> { 2400, 7200, 17000, 20500, 24000 } };
            game.Board.Add(genius);

            var shagga = new HorseCard() { Game = game, BoardIndex = 22, Title = "Shagga", Price = 6000, BoardLocation = Board.GetLocation(22), Stable = darkGreenStable, InspectionPrice = 500, BetCost = 4000, BetPrice = new List<int> { 2600, 7800, 18000, 22000, 25500 } };
            game.Board.Add(shagga);
            var dahoman = new HorseCard() { Game = game, BoardIndex = 23, Title = "Dahoman", Price = 6000, BoardLocation = Board.GetLocation(23), Stable = darkGreenStable, InspectionPrice = 500, BetCost = 4000, BetPrice = new List<int> { 2600, 7800, 18000, 22000, 25500 } };
            game.Board.Add(dahoman);
            var gira = new HorseCard() { Game = game, BoardIndex = 24, Title = "Gira", Price = 6400, BoardLocation = Board.GetLocation(24), Stable = darkGreenStable, InspectionPrice = 500, BetCost = 4000, BetPrice = new List<int> {3000, 9000, 20000, 24000, 28000 } };
            game.Board.Add(gira);

            var trainer4 = new TrainerCard() { Game = game, Title = "Trenér 4", BoardIndex = 25, BoardLocation = Board.GetLocation(25), InspectionPrice = 1000 };
            game.Board.Add(trainer4);

            var narcius = new HorseCard() { Game = game, BoardIndex = 26, Title = "Narcius", Price = 7000, BoardLocation = Board.GetLocation(26), Stable = purpleStable, InspectionPrice = 700, BetCost = 4000, BetPrice = new List<int> { 3500, 10000, 22000, 26000, 30000 } };
            game.Board.Add(narcius);
            var napoli = new HorseCard() { Game = game, BoardIndex = 27, Title = "Napoli", Price = 8000, BoardLocation = Board.GetLocation(27), Stable = purpleStable, InspectionPrice = 1000, BetCost = 4000, BetPrice = new List<int> { 4000, 12000, 28000, 34000, 40000 } };
            game.Board.Add(napoli);

            return game;
        }

        /// <summary>
        /// Metoda přemístí hráče podle jeho hodu kostkou. Vrátí instanci TurnResult a tím se dozvíme, jestli hráč prošel startem.
        /// </summary>
        /// <param name="game, player, rolledNumber"></param>
        /// <returns>Result, jestli hráč prošel startem.</returns>
        public TurnResult MovePlayer(Game game, Player player, int rolledNumber)
        {
            var result = new TurnResult() { GameOver = false, StartPassing = false };

            //Pokud dojdeme na konec hrací plochy, musíme se vrátit na začátek
            if (rolledNumber+player.BoardIndex > game.Board.Count-1)
            {
                player.BoardIndex = (player.BoardIndex + rolledNumber) - game.Board.Count;
                player.BoardLocation = Board.GetLocation(player.BoardIndex);
                result.StartPassing = true;
            }
            else
            {
                player.BoardIndex += rolledNumber;
                player.BoardLocation = Board.GetLocation(player.BoardIndex);
            }
            return result;
        }

        /// <summary>
        /// Metoda, která předá tah dalšímu hráči.
        /// </summary>
        /// <param name="game"></param>
        public void NextPlayer(Game game)
        {
            //Pokud dojdeme na konec listu s hráči, musíme se vrátit na začátek
            if(game.PlayerOnTurn.GameIndex == game.Players.Count - 1 )
            {
                game.PlayerOnTurn = game.Players.Where(x => x.GameIndex == 0).FirstOrDefault();
                game.PlayerOnTurn.DiceRolled = false;
            }
            else
            {
                game.PlayerOnTurn = game.Players.Where(x => x.GameIndex == (game.PlayerOnTurn.GameIndex + 1)).FirstOrDefault();
                game.PlayerOnTurn.DiceRolled = false;                
            }

            //Zjistíme, zda-li je hráč aktivní. Pokud není, zavoláme znovu metodu NextPlayer
            if (!game.PlayerOnTurn.IsActive)
            {
                NextPlayer(game);
            }
        }

        /// <summary>
        /// Metoda vrátí list s kartami požadovaného typu, které vlastní hráč převzaný z parametru.
        /// </summary>
        /// <param name="game, player"></param>
        /// <returns>List karet požadovaného typu, které hráč vlastní.</returns>
        public IList<Card> GetMyCards<T>(Game game, Player player) where T : Card
        {
            var result = game.Board.Where(x => x.GetType() == typeof(T) && x.Owner == player).ToList();
            return result;
        }

        /// <summary>
        /// Metoda dostane kartu koně a instanci hry, zjistí zda-li hráč vlastní všechny koně ze stáje. 
        /// Pokud ano, vrátí true, pokud ne, vrátí false.
        /// </summary>
        /// <param name="game, card"></param>
        /// <returns>True = stáj je kompletní, False = stáj není kompletní.</returns>
        public bool IsStableComplete(Game game, HorseCard card)
        {
            var horses = GetMyCards<HorseCard>(game, game.PlayerOnTurn).Cast<HorseCard>();           

            var result = horses.Where(x => x.Stable == card.Stable).ToList();

            //Porovnáme výsledek s počtem koní ve stáji
            if (result.Count == card.Stable.GetCountOfHorses(game.Board))
            {
                return true;
            }

            return false;           
        }

        /// <summary>
        /// Metoda pro zjištění, zda-li hra pořád běží.
        /// </summary>
        /// <param name="game"></param>
        /// <returns>True = hra skončila, False = hra běží.</returns>
        public bool IsGameOver(Game game)
        {
            //Zjistí zda-li je ve hře ještě dva a více aktivních hráčů
            return game.Players.Where(x => x.IsActive).Count() == 1;
        }
    }
}