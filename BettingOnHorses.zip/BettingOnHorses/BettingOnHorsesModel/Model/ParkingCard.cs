﻿using BettingOnHorsesModel.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace BettingOnHorsesModel.Model
{
    /// <summary>
    /// Třída představující kartu parkoviště. Parkoviště je karta, na které je hráč v bezpečí a nic se nědějě.
    /// </summary>
    public class ParkingCard : Card
    {
    }
}
