﻿using BettingOnHorses.Services;
using BettingOnHorsesLogic.Services;
using BettingOnHorsesModel.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BettingOnHorses
{
    /// <summary>
    /// Interaction logic for TrainerCardInformation.xaml
    /// Třída představující okno s kartou trenéra.
    /// </summary>
    public partial class TrainerCardInformation : Window
    {
        private readonly UIService uiservice;
        private readonly GameService _gameservice;

        public TrainerCardInformation(Game game, TrainerCard card, Grid grid)
        {
            InitializeComponent();
            uiservice = new UIService();
            _gameservice = new GameService();

            var lbTitle = new Label { Content = card.Title, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Bold, FontSize = 27 };
            var lbPrice = new Label { Content = card.Price, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Bold, FontSize = 27 };
            var imgIcon = new Image { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Source = new BitmapImage(new Uri("pack://siteoforigin:,,,/Resources/trainer2black.png", UriKind.Absolute)) };

            //Pokud má vlastníka, vypíše jeho jméno, pokud nemá, vypíše --- 
            if (card.Owner != null)
            {
                var lbOwner = new Label { Content = card.Owner.Name, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Bold, FontSize = 27 };
                Grid.SetColumn(lbOwner, 1);
                Grid.SetRow(lbOwner, 3);
                GridTrainerCardInformation.Children.Add(lbOwner);
            }
            else
            {
                var lbOwner = new Label { Content = "---", HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Bold, FontSize = 27 };
                Grid.SetColumn(lbOwner, 1);
                Grid.SetRow(lbOwner, 3);
                GridTrainerCardInformation.Children.Add(lbOwner);
            }

            Grid.SetColumn(lbTitle, 1);
            Grid.SetRow(lbTitle, 1);
            GridTrainerCardInformation.Children.Add(lbTitle);

            Grid.SetColumn(lbPrice, 1);
            Grid.SetRow(lbPrice, 2);
            GridTrainerCardInformation.Children.Add(lbPrice);

            Panel.SetZIndex(imgIcon, 1);

            Grid.SetColumn(imgIcon, 1);
            Grid.SetRow(imgIcon, 0);
            GridTrainerCardInformation.Children.Add(imgIcon);

            //Pokud je hráč na tahu vlastníkem karty, zobrazí se mu tlačítko prodat kartu
            if (card.Owner == game.PlayerOnTurn)
            {
                var buttonSell = new Button { Content = "Prodat", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Background = Brushes.LightGray, FontWeight = FontWeights.Bold };

                Grid.SetColumn(buttonSell, 1);
                Grid.SetRow(buttonSell, 5);
                GridTrainerCardInformation.Children.Add(buttonSell);

                buttonSell.Padding = new Thickness(8);

                //Přiřazení tagu tlačítka prodat, abychom mohli využít game, card a grid v metodě SellCard 
                buttonSell.Tag = new { Game = game, Card = card, Grid = grid };
                //Přidání metody po kliknuhí na tlačítko
                buttonSell.Click += SellCard;
            }

            //Pokud na kartě stojí hráč, který je na tahu a karta ještě nemá vlastníka, zobrazí se mu tlačítko koupit kartu
            if (card.BoardIndex == game.PlayerOnTurn.BoardIndex && card.Owner == null)
            {
                var buttonBuy = new Button { Content = "Koupit", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Background = Brushes.LightGray, FontWeight = FontWeights.Bold };
                Grid.SetColumn(buttonBuy, 0);
                Grid.SetRow(buttonBuy, 5);
                GridTrainerCardInformation.Children.Add(buttonBuy);

                buttonBuy.Padding = new Thickness(8);

                //Přiřazení tagu tlačítka koupit, abychom mohli využít game, card a grid v metodě BuyCard 
                buttonBuy.Tag = new { Game = game, Card = card, Grid = grid };
                //Přidání metody po kliknuhí na tlačítko
                buttonBuy.Click += BuyCard;
            }
        }

        /// <summary>
        /// Metoda pro koupi karty. Pokud má hráč finance na koupi karty, koupí jí a znovu se vykreslí aktuální herní plocha, pokud nemá dostatek financí, vypíše se hláška.
        /// </summary>
        public void BuyCard(object sender, EventArgs e)
        {
            //Vezmeme informace z tagu
            var send = (Button)sender;
            var card = ((dynamic)send.Tag).Card;
            Game game = ((dynamic)send.Tag).Game;
            Grid grid = ((dynamic)send.Tag).Grid;

            if (game.PlayerOnTurn.Cash >= card.Price)
            {     
                card.Owner = game.PlayerOnTurn;
                game.PlayerOnTurn.Cash -= card.Price;

                uiservice.DrawBoard(game, ref grid);
                this.Close();
            }
            else
            {
                MessageBox.Show("Kartu koupit nemůžete. Nemáte dostatek financí.", "Koupě karty se nezdařila");
            }
        }

        /// <summary>
        /// Metoda pro prodej karty. Vlastník karty je nastaven na null, hráči jsou přičteny peníze a znovu se vykreslí aktuální herní plocha.
        /// </summary>
        public void SellCard(object sender, EventArgs e)
        {
            //Vezmeme informace z tagu
            var send = (Button)sender;
            var card = ((dynamic)send.Tag).Card;
            Game game = ((dynamic)send.Tag).Game;
            Grid grid = ((dynamic)send.Tag).Grid;

            card.Owner = null;
            game.PlayerOnTurn.Cash += card.Price/2;

            uiservice.DrawBoard(game, ref grid);
            this.Close();
        }
    }

}
