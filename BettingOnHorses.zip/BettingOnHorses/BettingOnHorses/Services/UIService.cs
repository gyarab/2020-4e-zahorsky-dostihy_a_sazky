﻿using BettingOnHorsesLogic.Services;
using BettingOnHorsesModel.Contracts;
using BettingOnHorsesModel.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;

namespace BettingOnHorses.Services
{
    /// <summary>
    /// Třída představující grafiku hrací plochy. Třída má hlavní metodu DrawBoard, která připraví hrací plochu, všechny karty koní, trenérů a další.
    /// Zobrazí také statistiky všech hráčů ve hře. Zobrazí hrací kostku a hráče, který je právě na tahu. Umožní předat tah dalšímu hráči.
    /// </summary>
    public class UIService
    {
        private readonly GameService _gameservice;
        public UIService()
        {
            _gameservice = new GameService();
        }

        /// <summary>
        /// Metoda slouží pro vykreslení herní plochy. Zobrazí karty na hrací plochu, statistiky hráčů, kostku i s hráčem na tahu, 
        /// button pro předání tahu. 
        /// Grid je referenční typ, takže se nepředává hodnota, ale předává se reference.
        /// </summary>
        /// <param name="game, grid"></param>
        /// <returns></returns>
        public void DrawBoard(Game game, ref Grid grid)
        {
            //Smaže případné věci v gridu. Při obětovném volání metody DrawBoard je nezbytné, aby byl grid čistý
            grid.Children.Clear();

            if(game.Status == BettingOnHorsesModel.Enums.GameStatus.active)
            {
                if (!game.PlayerOnTurn.DiceRolled)
                {
                    //Přidání kostky 
                    StackPanel spDice = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };

                    var imgIconDice = new Image { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Source = new BitmapImage(new Uri("pack://siteoforigin:,,,/Resources/dice.png", UriKind.Absolute)), Height = 85 };
                    spDice.Children.Add(imgIconDice);

                    //Přiřazení tagu obrázku kostky, abychom mohli využít game a grid v metodě MovePlayerByDice 
                    //Tag se používá pro ukládání objektu
                    imgIconDice.Tag = new { Game = game, Grid = grid };
                    //Přidání metody po kliknuhí na obrázek kostky
                    imgIconDice.MouseDown += MovePlayerByDice;

                    Grid.SetColumn(spDice, 4);
                    Grid.SetRow(spDice, 4);
                    grid.Children.Add(spDice);
                }
                else
                {
                    //Přidání tlačítka pro předání tahu
                    var buttonNextPlayer = new Button { Content = "PŘEDEJTE TAH", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Background = Brushes.LightGray, FontWeight = FontWeights.Bold, FontSize = 12, Foreground = Brushes.Black };
                    buttonNextPlayer.Padding = new Thickness(8);

                    Grid.SetColumn(buttonNextPlayer, 4);
                    Grid.SetRow(buttonNextPlayer, 4);
                    grid.Children.Add(buttonNextPlayer);

                    //Přiřazení tagu tlačítku, abychom mohli využít game a grid v metodě PassTurn 
                    buttonNextPlayer.Tag = new { Game = game, Grid = grid };
                    //Přidání metody po kliknuhí na tlačítko
                    buttonNextPlayer.Click += PassTurn;
                }

                //Přidání aktuálního hráče
                StackPanel spCurrentPlayer = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };

                var lb = new Label { Content = "Hráč na tahu:", HorizontalAlignment = HorizontalAlignment.Center, Foreground = Brushes.Sienna, FontSize = 15, FontWeight = FontWeights.Bold };
                var lbCurrentPlayer = new Label { Content = game.PlayerOnTurn.Name, HorizontalAlignment = HorizontalAlignment.Center, FontSize = 21, FontWeight = FontWeights.Bold };
                var lbCash = new Label { Content = "Peníze: " + game.PlayerOnTurn.Cash, HorizontalAlignment = HorizontalAlignment.Center, Foreground = Brushes.Sienna, FontSize = 15, FontWeight = FontWeights.Bold };

                lbCurrentPlayer.Foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(game.PlayerOnTurn.Color);

                spCurrentPlayer.Children.Add(lb);
                spCurrentPlayer.Children.Add(lbCurrentPlayer);
                spCurrentPlayer.Children.Add(lbCash);

                Grid.SetColumn(spCurrentPlayer, 5);
                Grid.SetRow(spCurrentPlayer, 4);
                grid.Children.Add(spCurrentPlayer);
            }
            
            //Přidání statistik hráčů
            for (int i = 0; i < game.Players.Count; i++)
            {
                StackPanel spPlayerInfo = new StackPanel { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center };

                var lbPlayerTitle = new Label { Content = "Hráč: " + game.Players[i].Name, HorizontalAlignment = HorizontalAlignment.Left, Foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(game.Players[i].Color), FontWeight = FontWeights.Bold };
                var lbPlayerCash = new Label { Content = "Peníze: " + game.Players[i].Cash, HorizontalAlignment = HorizontalAlignment.Left, Foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(game.Players[i].Color) };

                spPlayerInfo.Children.Add(lbPlayerTitle);
                spPlayerInfo.Children.Add(lbPlayerCash);

                //Napsat ano, pokud je aktivní
                if (game.Players[i].IsActive)
                {
                    var lbPlayerIsActive = new Label { Content = "Je ve hře: Ano", HorizontalAlignment = HorizontalAlignment.Left, Foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(game.Players[i].Color) };
                    //Upravení prostoru kolem labelů, aby se vše věšlo do jedné buňky v gridu
                    lbPlayerIsActive.Margin = new Thickness(-5);
                    spPlayerInfo.Children.Add(lbPlayerIsActive);
                }
                else
                {
                    var lbPlayerIsActive = new Label { Content = "Je ve hře: Ne" , HorizontalAlignment = HorizontalAlignment.Left, Foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(game.Players[i].Color) };
                    //Upravení prostoru kolem labelů, aby se vše věšlo do jedné buňky v gridu
                    lbPlayerIsActive.Margin = new Thickness(-5);
                    spPlayerInfo.Children.Add(lbPlayerIsActive);
                }

                var lbPlayerHorseCards = new Label { Content = "Počet koní: " + _gameservice.GetMyCards<HorseCard>(game, game.Players[i]).Count, HorizontalAlignment = HorizontalAlignment.Left, Foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(game.Players[i].Color) };
                var lbPlayerTrainerCards = new Label { Content = "Počet trenérů: " + _gameservice.GetMyCards<TrainerCard>(game, game.Players[i]).Count, HorizontalAlignment = HorizontalAlignment.Left, Foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(game.Players[i].Color) };

                //Upravení prostoru kolem labelů, aby se vše věšlo do jedné buňky v gridu
                lbPlayerTitle.Margin = new Thickness(-5);
                lbPlayerCash.Margin = new Thickness(-5);
                lbPlayerHorseCards.Margin = new Thickness(-5);
                lbPlayerTrainerCards.Margin = new Thickness(-5);

                
                spPlayerInfo.Children.Add(lbPlayerHorseCards);
                spPlayerInfo.Children.Add(lbPlayerTrainerCards);

                Grid.SetColumn(spPlayerInfo, 0);
                Grid.SetRow(spPlayerInfo, i + 3);
                grid.Children.Add(spPlayerInfo);
            }

            //Přidání karet na hrací plochu
            foreach (var card in game.Board)
            {
                //Přidání karty startu
                if (card.GetType().Equals(typeof(StartCard)))
                {
                    StackPanel spStart = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                    spStart.Background = Brushes.MediumSeaGreen;
                    //Ohraničení stackpanelu
                    spStart.Margin = new Thickness(4);

                    var start = (StartCard)card;
                    var lbStart = new Label { Content = card.Title, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.White, FontSize = 25, FontWeight = FontWeights.Bold };

                    spStart.Children.Add(lbStart);
                    Grid.SetColumn(spStart, card.BoardLocation.X);
                    Grid.SetRow(spStart, card.BoardLocation.Y);
                    grid.Children.Add(spStart);

                    //Ohraničení karty
                    var myBorderStart = new Border();
                    myBorderStart.BorderThickness = new Thickness(1);
                    myBorderStart.BorderBrush = new SolidColorBrush(Colors.Gray);

                    Grid.SetColumn(myBorderStart, card.BoardLocation.X);
                    Grid.SetRow(myBorderStart, card.BoardLocation.Y);
                    grid.Children.Add(myBorderStart);
                }
                //Přidání karty parku
                else if (card.GetType().Equals(typeof(ParkingCard)))
                {
                    StackPanel spPark = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                    spPark.Background = Brushes.SteelBlue;
                    //Ohraničení stackpanelu
                    spPark.Margin = new Thickness(4);

                    var lbParkingSpot = new Label { Content = card.Title, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.White, FontSize = 14, FontWeight = FontWeights.Bold };

                    spPark.Children.Add(lbParkingSpot);
                    Grid.SetColumn(spPark, card.BoardLocation.X);
                    Grid.SetRow(spPark, card.BoardLocation.Y);
                    grid.Children.Add(spPark);

                    //Ohraničení karty
                    var myBorderPark = new Border();
                    myBorderPark.BorderThickness = new Thickness(1);
                    myBorderPark.BorderBrush = new SolidColorBrush(Colors.Gray);

                    Grid.SetColumn(myBorderPark, card.BoardLocation.X);
                    Grid.SetRow(myBorderPark, card.BoardLocation.Y);
                    grid.Children.Add(myBorderPark);
                }
                //Přidání karet trenérů a koní
                else
                {
                    StackPanel spInfo = new StackPanel { VerticalAlignment = VerticalAlignment.Top };
                    //Ohraničení stackpanelu
                    spInfo.Margin = new Thickness(4);

                    var lbTitle = new Label { Content = card.Title + " (" + card.Price + ")", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Top, Foreground = Brushes.Black, FontWeight = FontWeights.Bold };
                    var imgIcon = new Image { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Source = new BitmapImage(new Uri($"{card.ImageName}", UriKind.RelativeOrAbsolute)), Height = 45 };

                    
                    imgIcon.Margin = new Thickness(-2);

                    //Pokud je to karta koně, nastavíme barvu pozadí stackpanelu na barvu stáje
                    if (card.GetType().Equals(typeof(HorseCard)))
                    {
                        var horse = (HorseCard)card;
                        spInfo.Background = (SolidColorBrush)new BrushConverter().ConvertFromString(horse.Stable.StableColor);

                        //Zobrazíme žluté dostihy s jejich počtem
                        if(horse.NumberOfBets > 0 && horse.NumberOfBets < 5)
                        {
                            var imgBet = new Image { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center,  Source = new BitmapImage(new Uri("pack://siteoforigin:,,,/Resources/simplebet.png", UriKind.Absolute)), Height = 30 };
                            var lbBet = new Label { Content = horse.NumberOfBets, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Bold, FontSize = 15 };

                            //Upravíme číslo, aby bylo uprostřed obrázku dostihu
                            Thickness margin = lbBet.Margin;
                            margin.Left = 5;
                            lbBet.Margin = margin;

                            //Nastavíme zindex, aby se číslo zobrazovalo nad obrázkem
                            Panel.SetZIndex(imgBet, 2);
                            Panel.SetZIndex(lbBet, 3);

                            Grid.SetColumn(lbBet, card.BoardLocation.X);
                            Grid.SetRow(lbBet, card.BoardLocation.Y);
                            grid.Children.Add(lbBet);

                            Grid.SetColumn(imgBet, card.BoardLocation.X);
                            Grid.SetRow(imgBet, card.BoardLocation.Y);
                            grid.Children.Add(imgBet);
                        }
                        //Zobrazíme hlavní červený dostih s číslem 5
                        else if (horse.NumberOfBets == 5)
                        {
                            var imgBet = new Image { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Source = new BitmapImage(new Uri("pack://siteoforigin:,,,/Resources/mainbet.png", UriKind.Absolute)), Height = 30 };
                            var lbBet = new Label { Content = horse.NumberOfBets, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Black, FontWeight = FontWeights.Bold, FontSize = 15 };
                            
                            //Upravíme číslo, aby bylo uprostřed obrázku dostihu
                            Thickness margin = lbBet.Margin;
                            margin.Left = 5;
                            lbBet.Margin = margin;

                            //Nastavíme zindex, aby se číslo zobrazovalo nad obrázkem
                            Panel.SetZIndex(imgBet, 2);
                            Panel.SetZIndex(lbBet, 3);

                            Grid.SetColumn(lbBet, card.BoardLocation.X);
                            Grid.SetRow(lbBet, card.BoardLocation.Y);
                            grid.Children.Add(lbBet);

                            Grid.SetColumn(imgBet, card.BoardLocation.X);
                            Grid.SetRow(imgBet, card.BoardLocation.Y);
                            grid.Children.Add(imgBet);
                        }


                        
                    }
                    //Pokud je to karta trenéra, nastavíme barvu stackpanelu na šedou a bartu nápisu na bílou
                    else if (card.GetType().Equals(typeof(TrainerCard)))
                    {
                        var trainer = (TrainerCard)card;
                        spInfo.Background = Brushes.DarkGray;
                        lbTitle.Foreground = Brushes.White;
                    }

                    spInfo.Children.Add(lbTitle);
                    spInfo.Children.Add(imgIcon);

                    Panel.SetZIndex(spInfo, 1);


                    Grid.SetColumn(spInfo, card.BoardLocation.X);
                    Grid.SetRow(spInfo, card.BoardLocation.Y);
                    grid.Children.Add(spInfo);

                    //Přiřazení tagu obrázku koně/trenéra, abychom mohli využít game, card a grid v metodě ShowCardInformation 
                    spInfo.Tag = new { Game = game, Card = card, Grid = grid };
                    //Přidání metody po kliknuhí na obrázek koně/trenéra            
                    spInfo.MouseDown += ShowCardInformation;

                    //Ohraničení karty
                    var myBorder = new Border();
                    //Pokud karta nemá vlastníka, přiřadíme šedou barvu
                    if (card.Owner == null)
                    {
                        myBorder.BorderBrush = new SolidColorBrush(Colors.Gray);
                        myBorder.BorderThickness = new Thickness(1);
                    }
                    //Pokud karta má vlastníka, přiřadíme barvu hráče a přidáme tloušťku
                    else
                    {
                        myBorder.BorderBrush = (SolidColorBrush)new BrushConverter().ConvertFromString(card.Owner.Color);
                        myBorder.BorderThickness = new Thickness(3);
                    }

                    Grid.SetColumn(myBorder, card.BoardLocation.X);
                    Grid.SetRow(myBorder, card.BoardLocation.Y);
                    grid.Children.Add(myBorder);
                }

                //Přidání aktivních hráčů ve hře na jejich pozice na herní ploše
                for (var i = 0; i < game.Board.Count; i++)
                {
                    //Seznam hráčů na každé kartě
                    var players = game.Players.Where(x => x.BoardIndex == i);

                    StackPanel spPlayers = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, Orientation = Orientation.Horizontal};

                    //Pro každého hráče v seznamu hráčů na kartě
                    foreach (var player in players)
                    {
                        var lbPlayer = new Label { Content = player.Name, FontWeight = FontWeights.Bold };

                        //Nastavíme barvu na barvu hráče
                        lbPlayer.Foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(player.Color);
                        spPlayers.Children.Add(lbPlayer);

                        //Ohraničení stackpanelu
                        spPlayers.Margin = new Thickness(4);
                        //Aby byly jména hráčů uprostřed stackpanelu
                        Thickness margin = lbPlayer.Margin;
                        margin.Bottom = -3;
                        margin.Top = -2;
                        lbPlayer.Margin = margin;

                        Grid.SetColumn(spPlayers, player.BoardLocation.X);
                        Grid.SetRow(spPlayers, player.BoardLocation.Y);

                        //Na poli, na kterém se nachází aktivní hráč, zabarvíme stackpanel zeleně, aby se lépe orientoval
                        if(player == game.PlayerOnTurn)
                        {
                            spPlayers.Background = Brushes.PaleGreen;
                        }
                    }

                    grid.Children.Add(spPlayers);
                }
            }
        }

        /// <summary>
        /// Metoda, která zavolá kartu koně nebo trenéra, podle kliknutí.
        /// </summary>
        public void ShowCardInformation(object sender, EventArgs e)
        {
            //Vezmeme informace z tagu
            var source = (StackPanel)sender;
            var card = ((dynamic)source.Tag).Card;
            Game game = ((dynamic)source.Tag).Game;
            Grid grid = ((dynamic)source.Tag).Grid;

            //Pokud chceme zobrazit kartu koně
            if (typeof(HorseCard).Equals(card.GetType()))
            {
                var cardinfo = new HorseCardInformation(game, (HorseCard)card, grid);
                cardinfo.ShowDialog();
            }
            //Pokud chceme zobrazit kartu Trenéra
            else if (typeof(TrainerCard).Equals(card.GetType()))
            {
                var cardinfo = new TrainerCardInformation(game, (TrainerCard)card, grid);
                cardinfo.ShowDialog();
            }
        }

        /// <summary>
        /// Metoda, pro posunutí hráče na hrací ploše zavolaná po kliknutí na kostku.
        /// </summary>
        public void MovePlayerByDice(object sender, EventArgs e)
        {
            //Vezmeme informace z tagu
            var img = (Image)sender;
            Game game = ((dynamic)img.Tag).Game;
            Grid grid = ((dynamic)img.Tag).Grid;

            //Hodíme kostkou
            var rolled = game.Board.DiceRoll();

            //Posuneme hráče (nastavíme mu nový index a lokaci) a DiceRolled přiřadíme hodnotu true, aby hráč nemohl házet vícekrát
            var turnresult = _gameservice.MovePlayer(game, game.PlayerOnTurn, rolled);
            game.PlayerOnTurn.DiceRolled = true;

            //Vypíšeme hlášku o hodu kostkou
            MessageBox.Show("Hodil jste " + rolled + "!", "Hod kostkou");

            //Pokud hráč prošel startem, přidáme mu peníze a vypíšeme hlášku
            if (turnresult.StartPassing)
            {
                game.PlayerOnTurn.Cash += 4000;
                MessageBox.Show("Prošel jste startem, obdržíte 4000.", "Průchod startem");
            }

            //Zavoláme metodu DrawBoard, aby znovu vykresilala prací plochu již s posunutým hráčem
            DrawBoard(game, ref grid);

            //Zjistíme, na jaké kartě hráč stojí
            var card = game.Board.Where(x => x.BoardIndex == game.PlayerOnTurn.BoardIndex).FirstOrDefault();

            //Pokud je vlastník jiný hráč, zaplatíme určitou částku
            if (card.Owner != game.PlayerOnTurn && card.Owner != null)
            {
                //Platíme podle počtu trenérů
                if (card.GetType() == typeof(TrainerCard))
                {
                    var trainers = _gameservice.GetMyCards<TrainerCard>(game, card.Owner);
                    MessageBox.Show("Za prohlídku zaplatíte " + trainers.Count * trainers[0].InspectionPrice, "Platba hráči");
                    game.PlayerOnTurn.Cash -= trainers.Count * trainers[0].InspectionPrice;
                    card.Owner.Cash += trainers.Count * trainers[0].InspectionPrice;
                }
                else
                {
                    var horse = (HorseCard)card;

                    //Pokud jsou na koni žetony
                    if (horse.NumberOfBets > 0)
                    {
                        MessageBox.Show("Za prohlídku zaplatíte " + horse.BetPrice[horse.NumberOfBets - 1], "Platba hráči");
                        game.PlayerOnTurn.Cash -= (horse.BetPrice[horse.NumberOfBets - 1]);
                        card.Owner.Cash += horse.BetPrice[horse.NumberOfBets - 1];
                    }
                    //Pokud na koni žetony nejsou
                    else
                    {
                        MessageBox.Show("Za prohlídku zaplatíte " + card.InspectionPrice, "Platba hráči");
                        game.PlayerOnTurn.Cash -= card.InspectionPrice;
                        card.Owner.Cash += card.InspectionPrice;
                    }
                }

                //Zavoláme metodu DrawBoard, aby znovu vykresilala prací plochu již s posunutým hráčem
                DrawBoard(game, ref grid);
                
                //Zkontrolujeme, jestli hráč nezkrachoval, pokud ano, vyřadíme ho ze hry a všechny jeho karty vrátíme do hry
                if (game.PlayerOnTurn.Cash < 0)
                {
                    MessageBox.Show("Prohrál jste!", "Prohra hráče.");
                    for (var i = 0; i < game.Board.Count; i++)
                    {
                        if (game.Board[i].Owner == game.PlayerOnTurn)
                        {
                            game.Board[i].Owner = null;
                            if (game.Board[i].GetType() == typeof(HorseCard))
                            {
                                //Nezapomeneme nastavit hodnoty dostihů na výchozí hodnoty
                                var horse = (HorseCard)game.Board[i];
                                horse.NumberOfBets = 0;
                            }
                        }
                    }

                    //Nastavíme hráči konečné pořadí podle toho, kolik je ve hře aktivních hráčů a jeho zneaktivníme
                    game.PlayerOnTurn.BoardIndex = -(game.Players.Where(x => x.IsActive).Count());
                    game.PlayerOnTurn.IsActive = false;

                    //Zjistíme, zda-li se ve hře nachází poslední aktivní kráč, pokud ano, zobrazíme okno s koncem pořadím hráčů
                    if (_gameservice.IsGameOver(game))
                    {
                        var endofgame = new EndOfGame(game);
                        endofgame.ShowDialog();
                        game.Status = BettingOnHorsesModel.Enums.GameStatus.over;
                    }

                    //Vykreslíme aktuální hrací plochu
                    DrawBoard(game, ref grid);
                }
            }
        }

        /// <summary>
        /// Metoda, zavolaná kliknutím na tlačítko předat tah. 
        /// Předá tak dalšímu aktivnímu hráči a znovu vykreslí hrací plochu s aktuálními informacemi.
        /// </summary>
        public void PassTurn(object sender, EventArgs e)
        {
            //Vezmeme informace z tagu
            var send = (Button)sender;
            Game game = ((dynamic)send.Tag).Game;
            Grid grid = ((dynamic)send.Tag).Grid;
  
            _gameservice.NextPlayer(game);
            DrawBoard(game, ref grid);
        }
    }
}